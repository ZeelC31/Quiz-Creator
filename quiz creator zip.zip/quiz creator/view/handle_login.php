<?php

session_start();

require_once $_SERVER["DOCUMENT_ROOT"] . '/webmav_quiz/controller/CRUD.php';

extract($_POST);

$crudObject = new CRUD();

$userData = array();

$userData = $crudObject->fetchData('users', '*', ['user_email' => $userEmail]);

if (!empty($userData)) {
    $correctPassword = $userData[0]['user_password'];

    if ($correctPassword == $userPassword) {

        $_SESSION['loggedin'] = true;
        $_SESSION['userId'] = $userData[0]['user_id'];

        echo "login";
    } else {
        echo "Password is incorrect";
    }
} else {
    echo "Email is not regidtered with us";
}
