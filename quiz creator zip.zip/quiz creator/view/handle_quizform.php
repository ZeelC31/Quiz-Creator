<?php

require_once $_SERVER["DOCUMENT_ROOT"] . '/webmav_quiz/controller/CRUD.php';

$crudObject = new CRUD();

$questions = $crudObject->fetchData('questions', '*', ['quiz_id' => $_POST['quizId']]);

$correct = 0;
$wrong = 0;

foreach ($questions as $question) {
    $questionId = $question['question_id'];
    if ($question['correct_option'] == $_POST["$questionId"]) {
        $correct++;
    } else {
        $wrong++;
    }
}

echo '<div class="bg-warning-subtle p-4 rounded">
            <h3>Hey , Your respond has been recorded</h3>
            <p class="my-1">Total Questions : ' . $correct + $wrong . '</p>
            <p class="my-1">Correct Answer : ' . $correct . '</p>
            <p class="my-1">Wrong Answer : ' . $wrong . '</p>
        </div>';
