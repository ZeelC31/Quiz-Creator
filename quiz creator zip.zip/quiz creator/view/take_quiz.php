<?php
require_once $_SERVER["DOCUMENT_ROOT"] . '/webmav_quiz/controller/CRUD.php';
require_once '../model/constants.php';

?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Quiz Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.6.3.js" integrity="sha256-nQLuAZGRRcILA+6dMBOvcRh5Pe310sBpanc6+QBmyVM=" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<nav class="navbar navbar-expand-lg bg-dark navbar-dark">
    <div class="container-fluid">
        <span class="navbar-brand">Quiz Portal</span>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">

            </ul>
        </div>
    </div>
</nav>


<body>
    <div class="container">

        <?php

        $quizId = $_GET['quiz_id'];

        $crudObject = new CRUD();
        $quizData = $crudObject->fetchData('quiz', '*', ['quiz_id' => $quizId]);
        ?>

        <div class="mt-3 text-decoration-underline">
            <h3 class="text-center"><?php echo $quizData[0]['quiz_name']; ?></h3>
        </div>

        <?php
        $questions = $crudObject->fetchData('questions', '*', ['quiz_id' => $quizId]);
        ?>

        <form id="quizForm" method="post">
            <input type="hidden" name="quizId" id="quizId" value="<?php echo $quizId; ?>">
            <?php
            $i = 0;
            foreach ($questions as $question) {
                $i++;
            ?>
                <div class="mt-4">
                    <div>
                        <span class="fw-bold mb-1">Que.<?php echo $i; ?>: &nbsp;</span>
                        <span> <?php echo $question['question_desc']; ?> </span>
                    </div>
                    <div class="mt-2">
                        <div class="form-check">
                            <input required class="form-check-input" type="radio" value="<?php echo $question['option1']; ?>" name="<?php echo $question['question_id']; ?>" id="option<?php echo $question['question_id']; ?>1">
                            <label class="form-check-label" for="option<?php echo $question['question_id']; ?>1">
                                <?php echo $question['option1']; ?>
                            </label>
                        </div>
                        <div class="form-check">
                            <input required class="form-check-input" type="radio" value="<?php echo $question['option2']; ?>" name="<?php echo $question['question_id']; ?>" id="option<?php echo $question['question_id']; ?>2">
                            <label class="form-check-label" for="option<?php echo $question['question_id']; ?>2">
                                <?php echo $question['option2']; ?>
                            </label>
                        </div>
                        <div class="form-check">
                            <input required class="form-check-input" type="radio" value="<?php echo $question['option3']; ?>" name="<?php echo $question['question_id']; ?>" id="option<?php echo $question['question_id']; ?>3">
                            <label class="form-check-label" for="option<?php echo $question['question_id']; ?>3">
                                <?php echo $question['option3']; ?>
                            </label>
                        </div>
                        <div class="form-check">
                            <input required class="form-check-input" type="radio" value="<?php echo $question['option4']; ?>" name="<?php echo $question['question_id']; ?>" id="option<?php echo $question['question_id']; ?>4">
                            <label class="form-check-label" for="option<?php echo $question['question_id']; ?>4">
                                <?php echo $question['option4']; ?>
                            </label>
                        </div>
                    </div>
                </div>
            <?php
            }
            ?>

            <div class="mt-4 text-center">
                <button type="submit" class="btn btn-success">Submit</button>
            </div>
        </form>

        <!-- FOR RESULT SHOWING -->
        <div id="quizResult"></div>
    </div>


    <script src="../lib/js/take_quiz.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</body>

</html>