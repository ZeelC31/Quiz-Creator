<?php require_once "./header.php"; ?>

<div class="mt-3">
    <h3 class="text-center text-decoration-underline">All Questions</h3>
    <div class="text-end">
        <a href="./add_quesion.php?quiz_id=<?php echo $_GET['quiz_id']; ?>" class="btn btn-outline-primary"><span class="fas fa-plus"></span> Add Question</a>
    </div>

    <div class="mt-4">
        <?php
        $quizId = $_GET['quiz_id'];

        $crudObject = new CRUD();

        $questions = $crudObject->fetchData('questions', '*', ['quiz_id' => $quizId]);
        ?>

        <div class="table-responsive">
            <table class="table">
                <thead>
                    <th>#</th>
                    <th>Question</th>
                    <th>Option 1</th>
                    <th>Option 2</th>
                    <th>Option 3</th>
                    <th>Option 4</th>
                </thead>
                <tbody>

                    <?php
                    $i = 0;
                    foreach ($questions as $question) {
                        $i++;
                    ?>
                        <tr>
                            <td><?php echo $i; ?></td>
                            <td><?php echo $question['question_desc']; ?></td>
                            <td class="<?php if ($question['option1'] == $question['correct_option']) {
                                            echo "text-success";
                                        } else {
                                            echo "text-danger";
                                        } ?>"><?php echo $question['option1']; ?></td>
                            <td class="<?php if ($question['option2'] == $question['correct_option']) {
                                            echo "text-success";
                                        } else {
                                            echo "text-danger";
                                        } ?>"><?php echo $question['option2']; ?></td>
                            <td class="<?php if ($question['option3'] == $question['correct_option']) {
                                            echo "text-success";
                                        } else {
                                            echo "text-danger";
                                        } ?>"><?php echo $question['option3']; ?></td>
                            <td class="<?php if ($question['option4'] == $question['correct_option']) {
                                            echo "text-success";
                                        } else {
                                            echo "text-danger";
                                        } ?>"><?php echo $question['option4']; ?></td>

                        </tr>
                    <?php
                    }
                    ?>

                </tbody>
            </table>
        </div>
    </div>
</div>
</div>
<?php require_once "./footer.php"; ?>