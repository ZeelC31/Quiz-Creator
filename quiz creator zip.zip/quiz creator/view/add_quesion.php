<?php require_once "./header.php"; ?>


<div id="resultAlert" class="alert alert-warning alert-dismissible fade show" role="alert">
</div>


<div class="mt-3">
    <h3 class="text-center text-decoration-underline">Create Question</h3>
</div>
<div class="mt-4">
    <form id="addQuestionForm" method="post">
        <div class="mb-3">
            <label for="question" class="form-label">Enter Question</label>
            <textarea name="question" id="question" cols="30" rows="5" class="form-control">

            </textarea>
            <span id="questionErr" class="form-text text-danger"></span>
            <!-- HIDDEN FIELD -->
            <input type="hidden" name="quizId" id="quizId" value="<?php echo $_GET['quiz_id']; ?>">
        </div>
        <div class="mb-3 row">
            <div class="col-md-3">
                <label for="option1" class="form-label">Option 1</label>
                <input type="text" name="option1" id="option1" class="form-control option">
                <span id="option1Err" class="form-text text-danger"></span>
            </div>
            <div class="col-md-3">
                <label for="option2" class="form-label">Option 2</label>
                <input type="text" name="option2" id="option2" class="form-control option">
                <span id="option2Err" class="form-text text-danger"></span>
            </div>
            <div class="col-md-3">
                <label for="option3" class="form-label">Option 3</label>
                <input type="text" name="option3" id="option3" class="form-control option">
                <span id="option3Err" class="form-text text-danger"></span>
            </div>
            <div class="col-md-3">
                <label for="option4" class="form-label">Option 4</label>
                <input type="text" name="option4" id="option4" class="form-control option">
                <span id="option4Err" class="form-text text-danger"></span>
            </div>
        </div>
        <div class="mb-3">
            <label for="correctOption" class="form-label">Correct Option</label>
            <select name="correctOption" id="correctOption" class="form-select">
                <option value="">-- Select correct option --</option>
                <option value="1">Option 1</option>
                <option value="2">Option 2</option>
                <option value="3">Option 3</option>
                <option value="4">Option 4</option>
            </select>
            <span id="correctOptionErr" class="form-text text-danger"></span>
        </div>
        <div class="text-center">
            <button id="addQuestionBtn" type="submit" class="btn btn-outline-success">Add Question</button>
            <a href="./edit_quiz.php?quiz_id=<?php echo $_GET['quiz_id'];    ?>" class="btn btn-outline-danger">Back</a>
        </div>
    </form>
</div>

<script src="../lib/js/add_question.js"></script>

<?php require_once "./footer.php"; ?>