<?php

require_once $_SERVER["DOCUMENT_ROOT"] . '/webmav_quiz/controller/CRUD.php';

extract($_POST);

if (trim($quizName) != '') {
    $crudObject = new CRUD();

    $inserted = $crudObject->insertData('quiz', ['quiz_name' => $quizName]);

    if ($inserted) {
        echo "Success";
    } else {
        echo "Something went wrong , please try again later";
    }
} else {
    echo "Please enter quiz name";
}
