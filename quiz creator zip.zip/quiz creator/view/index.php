<?php require_once "./header.php"; ?>
<div class="mt-3">
    <h3 class="text-center text-decoration-underline">All Quiz</h3>
    <div class="text-end">
        <button id="createQuizBtn" class="btn btn-outline-primary"> <span class="fas fa-plus"></span> Create Quiz</button>
    </div>
</div>

<div class="mt-4">
    <?php
    $crudobject = new CRUD();

    $quizData = $crudobject->fetchData('quiz', '*');

    ?>

    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Quizname</th>
                    <th class="text-center">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $i = 0;
                foreach ($quizData as $quiz) {
                    $i++;
                ?>
                    <tr>
                        <td><?php echo $i; ?></td>
                        <td><?php echo $quiz['quiz_name']; ?></td>
                        <td class="text-center">
                            <a href="./edit_quiz.php?quiz_id=<?php echo $quiz['quiz_id']; ?>" class="btn btn-outline-primary"><span class="fas fa-pen-to-square"></span></a>
                            <a target="_blank" href="./take_quiz.php?quiz_id=<?php echo $quiz['quiz_id']; ?>" class="btn btn-outline-warning"><span class="fas fa-share"></span></a>
                        </td>
                    </tr>
                <?php
                }

                ?>
            </tbody>
        </table>
    </div>
</div>





<!-- CREATE QUIZ Modal -->
<div class="modal fade" id="createQuizModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="staticBackdropLabel">Create Quiz</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div>
                    <form id="createQuizForm" action="" method="post">
                        <div>
                            <label for="quizName" class="form-label">Quiz Name</label>
                            <input type="text" name="quizName" id="quizName" class="form-control">
                            <span id="quizNameErr" class="text-danger form-text"></span>
                        </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button id="createQuizModalBtn" type="submit" class="btn btn-primary">Create</button>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="../lib/js/index.js"></script>
<?php require_once "./footer.php"; ?>