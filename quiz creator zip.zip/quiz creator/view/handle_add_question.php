<?php

require_once $_SERVER["DOCUMENT_ROOT"] . '/webmav_quiz/controller/CRUD.php';

extract($_POST);

if (trim($question) != '' && trim($option1) != '' && trim($option2) != '' && trim($option3) != '' && trim($option4) != '' && trim($correctOption) != '') {

    switch ($correctOption) {
        case '1':
            $correctAnswer = $option1;
            break;
        case '2':
            $correctAnswer = $option2;
            break;
        case '3':
            $correctAnswer = $option3;
            break;
        case '4':
            $correctAnswer = $option4;
            break;
    }

    $questionData = [
        'question_desc' => $question,
        'option1' => $option1,
        'option2' => $option2,
        'option3' => $option3,
        'option4' => $option4,
        'correct_option' => $correctAnswer,
        'quiz_id' => $quizId
    ];

    $crudObject = new CRUD();

    $inserted = $crudObject->insertData('questions', $questionData);

    if ($inserted) {
        echo "Question Added!!!";
    } else {
        echo "Something went wrong , please try again";
    }
} else {
    echo "Fields can not be empty";
}
