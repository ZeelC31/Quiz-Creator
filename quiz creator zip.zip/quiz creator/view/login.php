<?php
require_once '../model/constants.php';

session_start();

if (isset($_SESSION['loggedin'])) {

    if ($_SESSION['loggedin'] === true) {
        header('Location: index.php');
    }
}
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Quiz Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.6.3.js" integrity="sha256-nQLuAZGRRcILA+6dMBOvcRh5Pe310sBpanc6+QBmyVM=" crossorigin="anonymous"></script>
</head>

<nav class="navbar navbar-expand-lg bg-dark navbar-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="./index.php">Quiz Portal</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">

            </ul>
        </div>
    </div>
</nav>


<body>
    <div class="container">

        <div id="resultAlert" class="alert alert-warning alert-dismissible fade show" role="alert">
        </div>

        <div class="mt-4">
            <h2 class="text-center">Login</h2>
            <div class="d-flex justify-content-center">
                <form id="loginForm" method="post" class="w-50">
                    <div class="mb-3">
                        <label for="userEmail" class="form-label">Enter email</label>
                        <input type="text" name="userEmail" id="userEmail" class="form-control">
                        <span id="userEmailErr" class="form-text text-danger"></span>
                    </div>
                    <div class="mb-3">
                        <label for="userPassword" class="form-label">Password</label>
                        <input type="text" name="userPassword" id="userPassword" class="form-control">
                        <span id="userPasswordErr" class="form-text text-danger"></span>
                    </div>
                    <div class="mb-3 text-center">
                        <button type="submit" class="btn btn-outline-primary w-25">Login</button>
                        <div>
                            <a href="./signup.php" class="text-decoration-none">Signup</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>


    </div>

    <script src="../lib/js/login.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</body>

</html>