<?php

require_once $_SERVER["DOCUMENT_ROOT"] . '/webmav_quiz/controller/CRUD.php';

extract($_POST);

if (trim($userName) != '' && trim($userEmail) != '' && strlen(trim($userPassword))) {
    if ($userPassword == $userConfirmPassword) {
        $crudObject = new CRUD();

        $userData = [
            'user_name' => $userName,
            'user_email' => $userEmail,
            'user_password' => $userPassword
        ];

        $inserted = $crudObject->insertData('users', $userData);

        if ($inserted) {
            session_start();

            $userData = $crudObject->fetchData('users', 'user_id', ['user_email' => $userEmail]);

            $_SESSION['loggedin'] = true;
            $_SESSION['userId'] = $userData[0]['user_id'];
            echo "Login";
        } else {
            echo "Something went wrong , please try again";
        }
    } else {
        echo "Both passwords does not match";
    }
} else {
    echo "Fields can not be empty";
}
