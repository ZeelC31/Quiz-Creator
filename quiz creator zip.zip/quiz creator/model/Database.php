<?php

require_once 'Config.php';

class Database
{
    private $serverName = SERVER_NAME;
    private $userName = USER_NAME;
    private $password = USER_PASSWORD;
    private $dbName = DB_NAME;

    protected function connect()
    {
        $conn = new mysqli($this->serverName, $this->userName, $this->password, $this->dbName);
        return $conn;
    }
}
