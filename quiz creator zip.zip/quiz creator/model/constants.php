<script>
    const SITE_URL = 'http://localhost/quiz/';
</script>

<?php

define("SITE_URL", "http://localhost/quiz/");
