<?php

define("SERVER_NAME","localhost");
define("USER_NAME","root");
define("USER_PASSWORD","");
define("DB_NAME","quiz");